import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LandingPage from '../pages/LandingPage';
import CounterPage from '../features/counter/page/CounterPage';
import LoginPage from '../features/auth/pages/LoginPage';
import RegisterPage from '../features/auth/pages/RegisterPage';
import MainDashboardPage from '../features/dashboard/pages/MainDashboardPage';
import  ProtectedRoute from './ProtectedRoute';
import DashboardHome from '../features/dashboard/pages/DashboardHome';
import ReferralsPage from '../features/referrals/pages/ReferralsPage';
import TasksPage from '../features/tasks/pages/TasksPage';
import TransactionsPage from '../features/transactions/pages/TransactionsPage';
import TransferPage from '../features/transfer/pages/TransfersPage';
export default function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<LandingPage />} />
        <Route path='/login' element={<LoginPage />} />
        <Route path='/register' element={<RegisterPage />} />


        <Route path='/dashboard'
         element={
          <ProtectedRoute>
            <MainDashboardPage />
          </ProtectedRoute>
         } >
          
          <Route index element={<DashboardHome />} />
          <Route path='referrals' element={<ReferralsPage />} />
          <Route path='tasks' element={<TasksPage />} />
          <Route path='transactions' element={<TransactionsPage />} />
          <Route path='transfer' element={<TransferPage />} />
        </Route>


        <Route path='/counter' element={<CounterPage />} />
      </Routes>
    </BrowserRouter>
  );
}
