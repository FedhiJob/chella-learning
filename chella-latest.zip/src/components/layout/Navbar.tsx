import React from 'react';
import { Link } from 'react-router-dom';
export default function Navbar() {
  return (
    <nav className=' flex justify-between p-3 bg-black text-white'>
        <div className='flex gap-2'>
           <div className='text-yellow-500 font-bold'>
             Chella 
            </div>
            <div>
                Reward App
            </div>
        </div>
       

       <div className=' flex gap-2 '>
            <Link to="/login" className='px-2 py-1 bg-black border border-yellow-500
             text-yellow-500 rounded-md'>Login</Link>
            <Link to='/register' className='px-2 py-1 bg-yellow-500 border border-yellow-500
             text-black rounded-md'>Get Started</Link>
       </div>
    </nav>
  );
}
