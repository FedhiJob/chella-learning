import React from 'react';
import { Link } from 'react-router-dom';
export default function Hero() {
    return (
        <div className='mx-auto py-6 '>
            <div className='text-center font-bold text-white text-[70px]'>
                Turn Every Action Into Reward <br />
                <div className='text-yellow-500'>
                    Reward
                </div>
            </div>
            <div className='text-center text-white mt-5 text-[20px]'>
                Earn bonuses, complete tasks and grow your network with Chella. Th

                The exclusive financial membership for the reward generation</div>


            <div className=' flex gap-2 justify-center mt-8'>
                <Link to='/register' className='px-2 py-1 bg-yellow-500 border border-yellow-500
             text-black rounded-md'>Get Started</Link>
                <Link to='/login' className='px-2 py-1 bg-black border border-yellow-500
             text-yellow-500 rounded-md'>Login to Account</Link>

            </div>
        </div>
    );
}
