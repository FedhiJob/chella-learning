export interface User{
    id: string;
    fullName: string;
    username: string;
    referralCode: string;
    amount: number;
  totalEarned: number;
  totalReffered: number;
}