import React from 'react';
import Navbar from '../components/layout/Navbar';
import Hero from '../components/layout/Hero';

export default function LandingPage() {
  return (
    <div className='bg-black text-black h-screen'>
        <Navbar />
        <Hero />
    </div>
  );
}
