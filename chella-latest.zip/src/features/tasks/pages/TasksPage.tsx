import React from 'react';
import TaskList from '../component/TaskList';
export default function TasksPage() {
  return (
    <>
    <TaskList />
    </>
  );
}
