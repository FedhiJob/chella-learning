import React,{useEffect} from 'react';
import { useAppDispatch,useAppSelector } from '../../../hooks/hooks';
import { getTodaysTask,completeTask } from '../slice/taskSlice';
import type { RootState } from '../../../store/store';
export default function TaskList() {
    const dispatch=useAppDispatch();
    
const {loading,completeLoading, tasks,error}=useAppSelector((state: RootState) => state.task);
    useEffect(()=>{
 
  dispatch(getTodaysTask());  

},[dispatch])


if(loading){
  return  <div> Loading</div>
}
if(error){
  return  <div>Error</div>
}
  

const complete=(id)=>{
    dispatch(completeTask(id))
}

  return (
    <div className="p-4  border border-gray-400">
        {tasks && tasks.length > 0 && tasks.map((task)=>(
            <div key={task.id} className='flex gap-2 my-5'>
                  <h1>
                    {task.title}
                    
                      {/* {task.taskDate} */}

                     
                  </h1>
                  <h1>
                     {task.rewardAmount}
                  </h1>
                  <button className='bg-white text-red-800'  onClick={()=>complete(task.id)}>
                {completeLoading ? 'Completing': 'complete'}    
                  </button>
            </div>
        ))}
    </div>
  );
}
