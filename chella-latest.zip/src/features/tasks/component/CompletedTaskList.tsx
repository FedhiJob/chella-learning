import React from 'react';

export default function CompletedTaskList() {
  return (
    <>

   CompletedTAsks 
    </>
  );
}
