import React from 'react';
import CounterDisplay from '../components/CounterDisplay';
import CounterStats from '../components/CounterStats';
import CounterControls from '../components/CounterControls';
import CounterHistory from '../components/CounterHistory';

export default function CounterPage() {
  return (
    <>
      <main className="space-y-8">
          <CounterDisplay />
          <CounterStats />
          <CounterControls />
          <CounterHistory />
        </main>
    </>
  );
}
