import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import type { RootState } from '../../store/store';

interface CounterState {
  value: number;
  previousValues: number[];
  step: number;
}

const initialState: CounterState = {
  value: 0,
  previousValues: [],
  step: 1,
};

const counterSlice = createSlice({
  name: 'counter',
  initialState,
  reducers: {
    increment: (state) => {
      state.previousValues.push(state.value);
      state.value += state.step;
    },
    decrement: (state) => {
      state.previousValues.push(state.value);
      state.value -= state.step;
    },
    incrementByAmount: (state, action: PayloadAction<number>) => {
      state.previousValues.push(state.value);
      state.value += action.payload;
    },
    setStep: (state, action: PayloadAction<number>) => {
      state.step = action.payload;
    },
    reset: (state) => {
      state.previousValues.push(state.value);
      state.value = 0;
    },
    undo: (state) => {
      if (state.previousValues.length > 0) {
        const previousValue = state.previousValues.pop();
        if (previousValue !== undefined) {
          state.value = previousValue;
        }
      }
    },
    clearHistory: (state) => {
      state.previousValues = [];
    },
  },
});


export const selectCount = (state: RootState) => state.counter.value;
export const selectPreviousValues = (state: RootState) => state.counter.previousValues;
export const selectStep = (state: RootState) => state.counter.step;
export const selectCanUndo = (state: RootState) => state.counter.previousValues.length > 0;
export const selectHistoryCount = (state: RootState) => state.counter.previousValues.length;
export const selectIsPositive = (state: RootState) => state.counter.value > 0;
export const selectIsNegative = (state: RootState) => state.counter.value < 0;
export const selectIsZero = (state: RootState) => state.counter.value === 0;

export const { 
  increment, 
  decrement, 
  incrementByAmount, 
  setStep, 
  reset, 
  undo, 
  clearHistory 
} = counterSlice.actions;

export default counterSlice.reducer;