import React, { useState } from 'react';
import { useAppSelector,useAppDispatch } from '../../../hooks/hooks';
import { 
  increment, 
  decrement, 
  incrementByAmount, 
  reset, 
  undo, 
  setStep,
  selectStep,
  selectCanUndo
} from '../counterSlice';

const CounterControls: React.FC = () => {
  const dispatch = useAppDispatch();
  const step = useAppSelector(selectStep);
  const canUndo = useAppSelector(selectCanUndo);
  const [customAmount, setCustomAmount] = useState('10');
  
  const handleStepChange = (newStep: number) => {
    dispatch(setStep(newStep));
  };
  
  const handleCustomAction = (isIncrement: boolean) => {
    const amount = parseInt(customAmount) || 0;
    if (isIncrement) {
      dispatch(incrementByAmount(amount));
    } else {
      dispatch(incrementByAmount(-amount));
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
      <div className="mb-8">
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Step Size</h3>
        <div className="flex flex-wrap gap-2">
          {[1, 2, 5, 10, 20].map((s) => (
            <button
              key={s}
              onClick={() => handleStepChange(s)}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                step === s 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {s} {step === s && '✓'}
            </button>
          ))}
        </div>
        <p className="text-gray-500 text-sm mt-2">
          Current step: <span className="font-bold">{step}</span>
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <button
          onClick={() => dispatch(decrement())}
          className="bg-red-500 hover:bg-red-600 text-white p-4 rounded-xl font-bold text-lg transition-colors shadow-md"
        >
          -{step}
        </button>
        
        <button
          onClick={() => dispatch(increment())}
          className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-xl font-bold text-lg transition-colors shadow-md"
        >
          +{step}
        </button>
        
        <button
          onClick={() => dispatch(reset())}
          className="bg-gray-500 hover:bg-gray-600 text-white p-4 rounded-xl font-bold text-lg transition-colors shadow-md"
        >
          Reset
        </button>
        
        <button
          onClick={() => dispatch(undo())}
          disabled={!canUndo}
          className={`p-4 rounded-xl font-bold text-lg transition-colors shadow-md ${
            canUndo 
              ? 'bg-purple-500 hover:bg-purple-600 text-white' 
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Undo
        </button>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Custom Amount</h3>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <input
              type="number"
              value={customAmount}
              onChange={(e) => setCustomAmount(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter custom amount"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => handleCustomAction(false)}
              className="px-6 py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium transition-colors"
            >
              - {customAmount}
            </button>
            <button
              onClick={() => handleCustomAction(true)}
              className="px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-medium transition-colors"
            >
              + {customAmount}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CounterControls;