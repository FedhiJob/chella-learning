import React from 'react';
import { useAppDispatch, useAppSelector } from '../../../hooks/hooks';
import { 
  selectPreviousValues, 
  selectHistoryCount,
  selectCanUndo,
  clearHistory 
} from '../counterSlice';

const CounterHistory: React.FC = () => {
  const dispatch = useAppDispatch();
  const previousValues = useAppSelector(selectPreviousValues);
  const historyCount = useAppSelector(selectHistoryCount);
  const canUndo = useAppSelector(selectCanUndo);

  if (previousValues.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8 text-center">
        <div className="text-gray-400 mb-4">
          <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <h3 className="text-xl font-semibold text-gray-700 mb-2">No History Yet</h3>
        <p className="text-gray-500">Start changing the counter value to see history here!</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-xl font-semibold text-gray-700">History</h3>
          <p className="text-gray-500 text-sm">
            {historyCount} change{historyCount !== 1 ? 's' : ''} recorded
            {canUndo && ' • Click "Undo" to go back'}
          </p>
        </div>
        <button
          onClick={() => dispatch(clearHistory())}
          className="px-4 py-2 text-sm bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors"
        >
          Clear History
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {[...previousValues].reverse().map((value, index) => {
          const isLatest = index === 0;
          const isOldest = index === previousValues.length - 1;
          const originalIndex = previousValues.length - 1 - index;

          return (
            <div
              key={originalIndex}
              className={`p-4 rounded-lg border transition-all ${
                isLatest 
                  ? 'bg-blue-50 border-blue-200 transform scale-105 shadow-sm' 
                  : isOldest
                  ? 'bg-gray-50 border-gray-200'
                  : 'bg-white border-gray-100'
              }`}
            >
              <div className="text-xs text-gray-500 mb-1">
                Step #{originalIndex + 1}
              </div>
              <div className={`text-2xl font-bold ${
                value > 0 ? 'text-green-600' : 
                value < 0 ? 'text-red-600' : 
                'text-blue-600'
              }`}>
                {value}
              </div>
              <div className="text-xs mt-2">
                {isLatest && (
                  <span className="inline-block px-2 py-1 bg-blue-100 text-blue-700 rounded-full">
                    Previous
                  </span>
                )}
                {isOldest && originalIndex !== 0 && (
                  <span className="inline-block px-2 py-1 bg-gray-100 text-gray-700 rounded-full">
                    Oldest
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CounterHistory;