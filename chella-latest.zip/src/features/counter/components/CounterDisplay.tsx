import React from 'react';
import { useAppSelector } from '../../../hooks/hooks';
import { 
  selectCount, 
  selectIsPositive, 
  selectIsNegative, 
  selectIsZero 
} from '../counterSlice';

const CounterDisplay: React.FC = () => {
  const count = useAppSelector(selectCount);
  const isPositive = useAppSelector(selectIsPositive);
  const isNegative = useAppSelector(selectIsNegative);
  const isZero = useAppSelector(selectIsZero);

  const getCountColor = () => {
    if (isPositive) return 'text-green-600';
    if (isNegative) return 'text-red-600';
    return 'text-blue-600';
  };

  const getStatusBgColor = () => {
    if (isPositive) return 'bg-green-100 text-green-800';
    if (isNegative) return 'bg-red-100 text-red-800';
    return 'bg-blue-100 text-blue-800';
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 text-center mb-8">
      <h2 className="text-2xl font-semibold text-gray-700 mb-4">Current Value</h2>
      
      <div className={`text-8xl font-bold mb-4 transition-colors duration-300 ${getCountColor()}`}>
        {count}
      </div>
      
      <div className={`inline-block px-4 py-2 rounded-full text-sm font-medium ${getStatusBgColor()}`}>
        {isPositive ? 'Positive' : isNegative ? 'Negative' : 'Zero'}
      </div>
      
      <div className="mt-4 text-gray-500 text-sm">
        {count > 100 ? '  High number' : 
         count < -100 ? ' Very low' : 
         'Change the value using buttons below'}
      </div>
    </div>
  );
};

export default CounterDisplay;