import React from 'react';

export default function TransferPage() {
  return (
    <>
    This is Transfers Page
    </>
  );
}
