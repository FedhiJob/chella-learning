import React from 'react';

export default function DashboardHome() {
  return (
    <div className='text-white'>
    This is the Dashboard Home Page
    </div>
  );
}
