import React from 'react';
import Referrals from '../components/Referrals';
export default function ReferralsPage() {
  return (
    <>
    <Referrals />
    </>
  );
}
