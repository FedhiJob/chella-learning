import { createSlice,createAsyncThunk } from "@reduxjs/toolkit"
import api from "../../../services/api";

const initialState = {
  referrals: null ,
  loading: false,
    error: null as string | null,
}


export const getMyReferrals = createAsyncThunk(
  'referral/getMyReferrals',
  async (
    _,
    { rejectWithValue }
  ) => {
    try {
      const response = await api.get('/referrals/my-referred-users');
    console.log(response.data)
 
      return response.data; 
    } catch (error: any) {
      console.log(error)
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          error.message ||
          'fetching failed',
        status: error.response?.status,
      });
    }
  }
);





const referralSlice=createSlice({
    name:"referral",
    initialState,
    reducers:{},
    // extraReducers:(builder)=>{
    //     builder
    // }
})

export default referralSlice.reducer;