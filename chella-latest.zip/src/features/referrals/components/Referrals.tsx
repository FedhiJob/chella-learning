import React,{useEffect} from 'react';
import { useAppDispatch } from '../../../hooks/hooks';
import { getMyReferrals } from '../slice/referralSlice';
export default function Referrals() {
    const dispatch=useAppDispatch();

    useEffect(()=>{
 
   dispatch(getMyReferrals())
    })
  return (
    <>
    
    </>
  );
}
