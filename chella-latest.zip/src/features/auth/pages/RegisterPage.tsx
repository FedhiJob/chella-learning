import React from 'react';
import Register from '../component/Register';
export default function RegisterPage() {
  return (
    <div className='bg-black flex w-full h-screen justify-center items-center'>
      <Register />
    </div>
  );
}
