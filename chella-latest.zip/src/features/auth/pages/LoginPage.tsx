import React from 'react';
import Login from '../component/Login';
export default function LoginPage() {
  return (
    <div className='bg-black  h-screen flex justify-center items-center w-full'>
    <Login />
    </div>
  );
}
