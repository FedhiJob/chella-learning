import React, { useState } from 'react';
import { useAppDispatch, useAppSelector } from '../../../hooks/hooks';
import { loginUser } from '../slice/authSlice';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
export default function Login() {
    const dispatch = useAppDispatch();
    const { user, loading, error } = useAppSelector((state: any) => state.auth);



    const navigate = useNavigate()

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');


    const handleLogin = async () => {
        const response =await dispatch(loginUser({ username, password }));
  console.log(response)
        if (response.meta.requestStatus == "fulfilled") {

            navigate('/dashboard');

        }
    }


    return (
        <div className='bg-gray-800 p-4 rounded-lg w-md my-10'>
            <div className='text-center text-2xl text-yellow-500 font-bold'>
                Chella
            </div>
            <div className='text-gray-300 text-lg text-ce nter mt-2'>
                Welcome back to your rewards
            </div>

            <div className='text-white font-bold  text-2xl'>
                Login to your account
            </div>

            <div className='space-y-2'>
                <div className='flex flex-col '>
                    <label className='text-white font-semibold'>Username</label>
                    <input type='text' value={username} onChange={(e) => setUsername(e.target.value)} className='p-2 rounded-md bg-gray-800 text-white
                 border border-gray-600' placeholder='Enter your username' />
                </div>

                <div className='flex flex-col '>
                    <label className='text-white font-semibold'>Password</label>
                    <input type='password' value={password} onChange={(e) => setPassword(e.target.value)} className='p-2 rounded-md bg-gray-800 text-white
                 border border-gray-600' placeholder='Enter your Password' />
                </div>

                <div className='text-right text-yellow-500 cursor-pointer'>
                    Forget Password?
                </div>

                <div>
                    <button onClick={handleLogin} className='px-2 w-full py-1 bg-yellow-500 border border-yellow-500
             text-black rounded-md'>{loading ? "Loading" : "Login"} </button>
                </div>
                {error && <div className='text-red-500 text-center'>{error}</div>}
                <div className='flex justify-end'>
                    <Link to="/register" className='text-yellow-500'>Create an account</Link>

                </div>
            </div>


        </div>
    );
}
