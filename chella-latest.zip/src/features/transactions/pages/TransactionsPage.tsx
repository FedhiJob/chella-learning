import React from 'react';

export default function TransactionsPage() {
  return (
    <>
    This is Transactions Page   
    </>
  );
}
